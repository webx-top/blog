-- Adminer 4.2.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `webx_album`;
CREATE TABLE `webx_album` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(180) NOT NULL COMMENT '标题',
  `description` varchar(200) NOT NULL DEFAULT '' COMMENT '简介',
  `content` text NOT NULL COMMENT '正文',
  `created` int(10) unsigned NOT NULL COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时间',
  `views` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `comments` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论次数',
  `likes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '喜欢次数',
  `display` enum('ALL','SELF','FRIEND','PWD') NOT NULL DEFAULT 'ALL' COMMENT '显示',
  `deleted` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `allow_comment` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '是否允许评论',
  `tags` varchar(255) NOT NULL DEFAULT '' COMMENT '标签',
  `catid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='相册';


DROP TABLE IF EXISTS `webx_attathment`;
CREATE TABLE `webx_attathment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) NOT NULL COMMENT '文件名',
  `path` varchar(255) NOT NULL COMMENT '保存路径',
  `extension` varchar(5) NOT NULL COMMENT '扩展名',
  `type` enum('image','media','other') NOT NULL DEFAULT 'image' COMMENT '文件类型',
  `size` bigint(20) unsigned NOT NULL COMMENT '文件尺寸',
  `uid` int(10) unsigned NOT NULL COMMENT 'UID',
  `deleted` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被删除时间',
  `created` int(10) unsigned NOT NULL COMMENT '创建时间',
  `audited` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '审核时间',
  `rc_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联id',
  `rc_type` varchar(30) NOT NULL DEFAULT '' COMMENT '关联类型',
  `tags` varchar(255) NOT NULL DEFAULT '' COMMENT '标签',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='附件表';


DROP TABLE IF EXISTS `webx_category`;
CREATE TABLE `webx_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类',
  `name` varchar(30) NOT NULL COMMENT '分类名称',
  `description` varchar(200) NOT NULL DEFAULT '' COMMENT '说明',
  `haschild` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT '是否有子分类',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `rc_type` varchar(30) NOT NULL DEFAULT 'post' COMMENT '关联类型',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `tmpl` varchar(100) NOT NULL DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='分类';


DROP TABLE IF EXISTS `webx_comment`;
CREATE TABLE `webx_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `content` text NOT NULL COMMENT '内容',
  `quote` text COMMENT '引用内容',
  `etype` char(10) NOT NULL DEFAULT 'html' COMMENT '编辑器类型',
  `root_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `r_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '关联本表的id',
  `r_type` enum('reply','append') DEFAULT NULL COMMENT '关联类型（reply-回复，append-追加）',
  `related_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '本身被回复次数',
  `root_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点下的所有回复次数',
  `uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '发布者id',
  `uname` varchar(30) NOT NULL COMMENT '发布者用户名',
  `up` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被顶次数',
  `down` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被踩次数',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `rc_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '关联内容ID',
  `rc_type` char(30) NOT NULL DEFAULT 'post' COMMENT '关联内容类型',
  `for_uname` varchar(30) DEFAULT NULL COMMENT '被评人用户名',
  `for_uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被评人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论';


DROP TABLE IF EXISTS `webx_config`;
CREATE TABLE `webx_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `key` varchar(60) NOT NULL COMMENT '配置项',
  `val` varchar(200) NOT NULL COMMENT '配置值',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='网站配置';


DROP TABLE IF EXISTS `webx_link`;
CREATE TABLE `webx_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(30) NOT NULL COMMENT '名称',
  `url` varchar(200) NOT NULL COMMENT '网址',
  `logo` varchar(200) NOT NULL COMMENT 'LOGO',
  `show` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT '是否显示',
  `verified` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证时间',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `catid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='友情链接';


DROP TABLE IF EXISTS `webx_ocontent`;
CREATE TABLE `webx_ocontent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `rc_id` int(10) unsigned NOT NULL COMMENT '关联ID',
  `rc_type` varchar(30) NOT NULL DEFAULT 'post' COMMENT '关联类型',
  `content` text NOT NULL COMMENT '博客原始内容',
  `etype` enum('markdown') NOT NULL DEFAULT 'markdown' COMMENT '编辑器类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='原始内容';


DROP TABLE IF EXISTS `webx_post`;
CREATE TABLE `webx_post` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(180) NOT NULL COMMENT '标题',
  `description` varchar(200) NOT NULL COMMENT '简介',
  `content` text NOT NULL COMMENT '内容',
  `etype` enum('html','markdown') NOT NULL DEFAULT 'html' COMMENT '编辑器类型',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `display` enum('ALL','SELF','FRIEND','PWD') NOT NULL DEFAULT 'ALL' COMMENT '显示',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'UID',
  `uname` varchar(30) NOT NULL DEFAULT '' COMMENT '作者名',
  `passwd` varchar(64) NOT NULL DEFAULT '' COMMENT '访问密码',
  `views` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被浏览次数',
  `comments` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被评论次数',
  `likes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被喜欢次数',
  `deleted` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被删除时间',
  `year` int(5) unsigned NOT NULL COMMENT '归档年份',
  `month` tinyint(1) unsigned NOT NULL COMMENT '归档月份',
  `allow_comment` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '是否允许评论',
  `tags` varchar(255) NOT NULL DEFAULT '' COMMENT '标签',
  `catid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='博客';

INSERT INTO `webx_post` (`id`, `title`, `description`, `content`, `etype`, `created`, `updated`, `display`, `uid`, `uname`, `passwd`, `views`, `comments`, `likes`, `deleted`, `year`, `month`, `allow_comment`, `tags`, `catid`) VALUES
(1,	'你好，世界',	'这是我的第一篇博客。',	'这是我的第一篇博客。',	'html',	0,	1456897834,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	9999,	1,	'Y',	'测试,haha',	1),
(2,	'0000000000000',	'000000000000',	'5555555555555555555555555',	'html',	1456898360,	1456902036,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'00000',	1),
(3,	'22222222222222',	'3333333333333',	'3333333333333333333333333<img alt=\"微笑\" src=\"/admin/assets/js/editor/xheditor/xheditor_emot/default/smile.gif\" />',	'html',	1456900128,	1456900128,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'',	1),
(4,	'22222222222222',	'3333333333333',	'3333333333333333333333333<img alt=\"微笑\" src=\"/admin/assets/js/editor/xheditor/xheditor_emot/default/smile.gif\" /><img src=\"/upload/image/2016/3/2/126cbf59-e040-11e5-9089-74d435423fa9.png\" alt=\"杂志+-+读览天下.png\" />',	'html',	1456900197,	1456900197,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'',	1),
(5,	'6666666666666',	'66666666666667777777',	'88888888888888888888888888<img alt=\"大笑\" src=\"/admin/assets/js/editor/xheditor/xheditor_emot/default/laugh.gif\" />',	'html',	1456900496,	1456900496,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'',	1),
(6,	'uuuuuuuuuuu',	'7777777777777777777',	'8888888888888888888888888888<img alt=\"哭\" src=\"/admin/assets/js/editor/xheditor/xheditor_emot/default/cry.gif\" />',	'html',	1456901008,	1456901025,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'',	1),
(7,	'呃呃呃呃呃呃呃呃呃呃呃呃',	'3333333333333',	'333333333333333333333333333',	'html',	1456902094,	1456902094,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'',	1),
(8,	'000000000000000',	'0000000000000000000',	'00000000000000000000000',	'html',	1456904026,	1456904026,	'ALL',	1,	'admin',	'',	0,	0,	0,	0,	2016,	3,	'Y',	'',	1);

DROP TABLE IF EXISTS `webx_tag`;
CREATE TABLE `webx_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(30) NOT NULL COMMENT '标签名',
  `uid` int(10) unsigned NOT NULL COMMENT '创建者',
  `created` int(10) unsigned NOT NULL COMMENT '创建时间',
  `times` int(10) unsigned NOT NULL COMMENT '使用次数',
  `rc_type` varchar(30) NOT NULL DEFAULT 'post' COMMENT '关联类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='标签';


DROP TABLE IF EXISTS `webx_user`;
CREATE TABLE `webx_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'UID',
  `uname` varchar(30) NOT NULL COMMENT '用户名',
  `passwd` char(64) NOT NULL COMMENT '密码',
  `salt` char(64) NOT NULL COMMENT '盐值',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '邮箱',
  `mobile` varchar(15) NOT NULL DEFAULT '' COMMENT '手机号',
  `login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次登录时间',
  `login_ip` varchar(40) NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `active` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '激活',
  `avatar` varchar(200) NOT NULL DEFAULT '' COMMENT '头像',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户资料';

INSERT INTO `webx_user` (`id`, `uname`, `passwd`, `salt`, `email`, `mobile`, `login_time`, `login_ip`, `created`, `updated`, `active`, `avatar`) VALUES
(1,	'admin',	'c02773b76842113d68be0921fa58c7bbbc72179a32114ba46dbfdf96d8a6d266',	'33c287a34a937a6e359482656742a83b9607b4fc0e4af9c0e8d9e9434309e8ba',	'',	'',	0,	'',	1454490317,	1454490317,	'',	''),
(2,	'admin2',	'e7cbce76cbeba42e21cc42e8522f5582cc09e64da78bb96166db238b95a34ef5',	'679caa5b9adcd59223a2d56d0f0bb21ce8d0042bc777e9ff7bd45ca47c111fee',	'',	'',	0,	'',	1454492025,	1454492025,	'N',	''),
(3,	'user',	'8a8d76545b3bb08057fe0ac29c963c364d96214dab784070c4ab94e8386c2c7e',	'7efc3ebe4990967a8272a483cb1c2dfabf0e95c7918de650032288e69d8b9972',	'',	'',	0,	'',	1454496034,	1454496034,	'N',	'');

-- 2016-03-02 08:16:56
